<?php
require 'dbh.php';
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
</head>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html, body {
        height: 100%;
        width: 100%;
        font-family: 'Montserrat', sans-serif;
        background-color: #f4f6f9;
    }

    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
        height: 80px;
        background-color: #202940; /* Solid Dark Blue Background */
        border-bottom: 3px solid #FB8506; /* Orange Bottom Border */
        color: #ffffff; /* White Text */
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .header h1 {
        font-size: 1.8rem;
        font-weight: 600;
        margin: 0;
    }

    .header .logout {
        display: flex;
        align-items: center;
    }

    .logout button {
        background-color: #FB8506; /* Bright Orange */
        color: #ffffff; /* White Text */
        border: none;
        padding: 10px 20px;
        font-size: 1rem;
        font-weight: 500;
        border-radius: 5px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .logout button:hover {
        background-color: #d97404; /* Slightly Darker Orange */
        transform: scale(1.05);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .logout button a {
        text-decoration: none;
        color: inherit;
        font-weight: bold;
    }

    @media (max-width: 768px) {
        .header {
            flex-direction: column;
            align-items: center;
            text-align: center;
            height: auto;
            padding: 20px;
        }

        .header h1 {
            font-size: 1.6rem;
            margin-bottom: 10px;
        }

        .logout button {
            font-size: 0.9rem;
            padding: 8px 15px;
        }
    }
</style>
<body>

    <div class="header">
        <h1>MINI SAP System</h1>
        <div class="logout">
            <a href="../login.html"><button>Log Out</button></a>
        </div>
    </div>

</body>
</html>
